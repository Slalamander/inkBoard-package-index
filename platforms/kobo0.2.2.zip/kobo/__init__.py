"""
Kobo Ereader class.
"""