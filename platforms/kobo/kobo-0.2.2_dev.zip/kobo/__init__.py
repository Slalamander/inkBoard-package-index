"""
Kobo Ereader class.
"""