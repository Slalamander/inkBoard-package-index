
DEFAULT_PORT = 9141
DEFAULT_HOST_PATTERN = r'(localhost|127\.0\.0\.1|192\.168\.([0-9]+)\.([0-9]+))'